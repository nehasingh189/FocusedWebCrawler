package com.Crawler;


public class CrawledData {
	public int depth;
	public String url;
/**
 * 	
 * @param newDepth
 * @param newUrl
 */
	public CrawledData(int newDepth, String newUrl){
		this.depth = newDepth;
		this.url = newUrl;
	}
}
